package com.vernu.sms.helpers

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class DeviceLogTest {
    @Test
    fun masksPhoneNumbersButKeepsTheLastFourDigits() {
        assertEquals("sent to …0142", DeviceLog.redact("sent to +15550100142"))
        assertEquals("from …0142", DeviceLog.redact("from +1 (555) 010-0142"))
        assertEquals("to …0142", DeviceLog.redact("to 555-010-0142"))
        assertEquals("code 4 attempt 3", DeviceLog.redact("code 4 attempt 3"))
        assertEquals("version 2.9.0 (20)", DeviceLog.redact("version 2.9.0 (20)"))
        assertEquals("id …7890 and …4321", DeviceLog.redact("id 1234567890 and 09876554321"))
    }

    @Test
    fun keepsOnlyTheNewestEntries() {
        val many = (1..DeviceLog.MAX_ENTRIES + 20).map { LogEntry(it.toLong(), "e", "", null) }
        val kept = DeviceLog.trim(many, nowMs = DeviceLog.MAX_ENTRIES.toLong())
        assertEquals(DeviceLog.MAX_ENTRIES, kept.size)
        assertEquals(21L, kept.first().timeMs)
    }

    @Test
    fun dropsEntriesOlderThanTheMaxAge() {
        val now = DeviceLog.MAX_AGE_MS * 2
        val entries = listOf(now - DeviceLog.MAX_AGE_MS - 1, now - DeviceLog.MAX_AGE_MS, now)
            .map { LogEntry(it, "e", "", null) }
        val kept = DeviceLog.trim(entries, nowMs = now)
        assertEquals(listOf(now - DeviceLog.MAX_AGE_MS, now), kept.map { it.timeMs })
    }

    @Test
    fun keepsTheListWhenNothingIsTrimmed() {
        val entries = listOf(LogEntry(10L, "e", "", null), LogEntry(20L, "e", "", null))
        assertEquals(entries, DeviceLog.trim(entries, nowMs = 20L))
    }

    @Test
    fun linesRoundTripAndTabsAreFlattened() {
        val entry = LogEntry(1700000000000L, "send_attempted", "delay 5s\tsim 1", "abc123")
        val parsed = DeviceLog.parseLine(DeviceLog.formatLine(entry))
        assertEquals(entry.copy(detail = "delay 5s sim 1"), parsed)
        assertNull(DeviceLog.parseLine("garbage"))
        assertEquals(null, DeviceLog.parseLine("1\tevent\t\t")?.smsId)
    }
}

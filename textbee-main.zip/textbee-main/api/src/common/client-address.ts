// Where a request actually came from.
//
// The API runs behind a reverse proxy, and in the hosted deployment behind a
// CDN in front of that. `req.ip` is therefore the address of the nearest hop
// the app trusts, which for every request is the edge, not the caller. The
// edge forwards the caller's address and its region in its own headers, so
// when the deployment declares that it runs behind one, those headers are the
// better source.
//
// Headers are only as trustworthy as the deployment that sets them, so the
// values here are used to label analytics and to key the rate limiter, never
// for authorisation.

import { isIP } from 'net'

// Regions the edge reports when it cannot place the address: the unknown
// placeholder, and the code used for requests from the Tor network.
const UNPLACED_REGIONS = new Set(['XX', 'T1'])

// IPv6 is recorded at this prefix length. See canonicalAddress.
const IPV6_PREFIX_GROUPS = 4

type HeaderBag = Record<string, string | string[] | undefined> | undefined

const CONTINENTS = new Set(['AF', 'AN', 'AS', 'EU', 'NA', 'OC', 'SA'])

const MAX_PLACE_NAME = 64
const MAX_ASN = 4294967295

const CONTROL_CHARACTERS = /[\u0000-\u001f\u007f]/g

export type ClientLocation = {
  region?: string
  regionCode?: string
  city?: string
  continent?: string
  timezone?: string
  asn?: number
}

export const LOCATION_FIELDS = [
  'region',
  'regionCode',
  'city',
  'continent',
  'timezone',
  'asn',
] as const

export type ClientAddress = {
  ip?: string
  country?: string
} & ClientLocation

function headerValue(value: string | string[] | undefined): string | undefined {
  if (Array.isArray(value)) return value[0]
  return value
}

/** Expands an IPv6 address to its eight groups, or undefined if malformed. */
function expandIpv6(value: string): string[] | undefined {
  let text = value

  // A trailing dotted quad ("::ffff:203.0.113.5") is two groups written in
  // IPv4 notation. Rewrite it so the rest of this function sees only groups.
  const lastColon = text.lastIndexOf(':')
  const tail = text.slice(lastColon + 1)
  if (tail.includes('.')) {
    const octets = tail.split('.').map((part) => Number(part))
    if (octets.length !== 4) return undefined
    if (octets.some((n) => !Number.isInteger(n) || n < 0 || n > 255)) {
      return undefined
    }
    const high = ((octets[0] << 8) | octets[1]).toString(16)
    const low = ((octets[2] << 8) | octets[3]).toString(16)
    text = `${text.slice(0, lastColon + 1)}${high}:${low}`
  }

  const halves = text.split('::')
  if (halves.length > 2) return undefined

  const head = halves[0] ? halves[0].split(':') : []
  const rest = halves.length === 2 && halves[1] ? halves[1].split(':') : []

  let groups: string[]
  if (halves.length === 2) {
    const missing = 8 - head.length - rest.length
    if (missing < 0) return undefined
    groups = [...head, ...Array(missing).fill('0'), ...rest]
  } else {
    if (head.length !== 8) return undefined
    groups = head
  }

  const normalised = groups.map((group) => {
    const parsed = Number.parseInt(group, 16)
    return Number.isNaN(parsed) ? undefined : parsed.toString(16)
  })
  return normalised.some((group) => group === undefined)
    ? undefined
    : (normalised as string[])
}

/**
 * One stable spelling for an address, or nothing when it does not parse.
 *
 * Lower cased, with the interface suffix of a link-local address dropped and
 * an IPv4 caller on a dual-stack socket unwrapped from its ::ffff: form. The
 * address itself is kept whole, which is what ad platforms and support
 * transcripts need.
 */
export function rawAddress(value: unknown): string | undefined {
  if (typeof value !== 'string') return undefined

  // A link-local address carries the interface it arrived on after a %. That
  // is local to the host and not part of the address.
  let text = value.trim().split('%')[0].toLowerCase()
  if (!text) return undefined

  // IPv4 tunnelled through an IPv6 socket, which is how a dual-stack listener
  // reports every IPv4 caller.
  if (text.startsWith('::ffff:') && isIP(text.slice(7)) === 4) {
    text = text.slice(7)
  }

  return isIP(text) ? text : undefined
}

/**
 * The address reduced to one value per caller, for counting distinct origins.
 *
 * IPv4 is kept whole. IPv6 becomes its /64 network, because a mobile carrier
 * hands out a network and the device picks a new interface id within it
 * several times a day. Keeping the full address would count one phone as
 * dozens of different origins.
 */
export function canonicalAddress(value: unknown): string | undefined {
  const text = rawAddress(value)
  if (!text) return undefined
  if (isIP(text) === 4) return text

  const groups = expandIpv6(text)
  if (!groups) return undefined
  return `${groups.slice(0, IPV6_PREFIX_GROUPS).join(':')}::/64`
}

/** A two-letter region code, or nothing when the edge could not place it. */
export function cleanCountry(value: unknown): string | undefined {
  if (typeof value !== 'string') return undefined
  const code = value.trim().toUpperCase()
  if (!/^[A-Z]{2}$/.test(code)) return undefined
  return UNPLACED_REGIONS.has(code) ? undefined : code
}

/** Header values arrive as latin1, so raw UTF-8 bytes show up as mojibake. */
function repairUtf8(text: string): string {
  if (!/[\u0080-\u00ff]/.test(text) || /[^\u0000-\u00ff]/.test(text)) {
    return text
  }
  const decoded = Buffer.from(text, 'latin1').toString('utf8')
  return decoded.includes('\ufffd') ? text : decoded
}

/** A region or city name, bounded and decoded, or nothing. */
export function cleanPlaceName(value: unknown): string | undefined {
  if (typeof value !== 'string') return undefined
  let text = value
  if (text.includes('%')) {
    try {
      text = decodeURIComponent(text)
    } catch {
      // Not percent encoded after all.
    }
  }
  text = repairUtf8(text).replace(CONTROL_CHARACTERS, '').trim()
  return text ? text.slice(0, MAX_PLACE_NAME) : undefined
}

/** A subdivision code such as "CA" or "ENG". */
export function cleanRegionCode(value: unknown): string | undefined {
  if (typeof value !== 'string') return undefined
  const code = value.trim().toUpperCase()
  return /^[A-Z0-9]{1,3}$/.test(code) ? code : undefined
}

export function cleanContinent(value: unknown): string | undefined {
  if (typeof value !== 'string') return undefined
  const code = value.trim().toUpperCase()
  return CONTINENTS.has(code) ? code : undefined
}

/** An IANA zone name this runtime can format dates in. */
export function cleanTimezone(value: unknown): string | undefined {
  if (typeof value !== 'string') return undefined
  const zone = value.trim()
  if (!/^[A-Za-z][A-Za-z0-9_+\-]*(\/[A-Za-z0-9_+\-]+){0,2}$/.test(zone)) {
    return undefined
  }
  try {
    new Intl.DateTimeFormat('en', { timeZone: zone })
    return zone
  } catch {
    return undefined
  }
}

export function cleanAsn(value: unknown): number | undefined {
  const text = typeof value === 'number' ? String(value) : value
  if (typeof text !== 'string' || !/^\d{1,10}$/.test(text.trim())) {
    return undefined
  }
  const asn = Number(text.trim())
  return asn > 0 && asn <= MAX_ASN ? asn : undefined
}

/** Cleans each location field and keeps only the ones that survive. */
export function cleanLocation(
  input:
    | {
        region?: unknown
        regionCode?: unknown
        city?: unknown
        continent?: unknown
        timezone?: unknown
        asn?: unknown
      }
    | undefined,
): ClientLocation {
  const location: ClientLocation = {
    region: cleanPlaceName(input?.region),
    regionCode: cleanRegionCode(input?.regionCode),
    city: cleanPlaceName(input?.city),
    continent: cleanContinent(input?.continent),
    timezone: cleanTimezone(input?.timezone),
    asn: cleanAsn(input?.asn),
  }
  for (const field of LOCATION_FIELDS) {
    if (location[field] === undefined) delete location[field]
  }
  return location
}

/** The location fields of a context, or undefined when it has none. */
export function pickLocation(
  context: ClientLocation | undefined,
): ClientLocation | undefined {
  const location = cleanLocation(context)
  return Object.keys(location).length ? location : undefined
}

function locationFromHeaders(headers: NonNullable<HeaderBag>): ClientLocation {
  return cleanLocation({
    region: headerValue(headers['cf-region']),
    regionCode: headerValue(headers['cf-region-code']),
    city: headerValue(headers['cf-ipcity']),
    continent: headerValue(headers['cf-ipcontinent']),
    timezone: headerValue(headers['cf-timezone']),
    asn: headerValue(headers['x-client-asn']),
  })
}

/**
 * The caller's address and region for this request. The address is whole;
 * pass it through canonicalAddress when counting distinct origins.
 *
 * Set TRUSTED_PROXY=cloudflare when the deployment sits behind that edge, so
 * the values come from its headers. Unset, the proxy hop is used and no region
 * is available.
 */
export function resolveClientAddress(req?: {
  ip?: string
  headers?: HeaderBag
}): ClientAddress {
  const fallback = rawAddress(req?.ip)

  if (process.env.TRUSTED_PROXY !== 'cloudflare') {
    return fallback ? { ip: fallback } : {}
  }

  const headers = req?.headers ?? {}
  // Whole, like the fallback. Reducing it here would hand a network to the
  // conversions API and to the billing provider, and would leave the callers
  // that do want one value per caller unable to parse it back.
  const ip = rawAddress(headerValue(headers['cf-connecting-ip'])) ?? fallback
  const country = cleanCountry(headerValue(headers['cf-ipcountry']))

  return {
    ...(ip && { ip }),
    ...(country && { country }),
    ...locationFromHeaders(headers),
  }
}

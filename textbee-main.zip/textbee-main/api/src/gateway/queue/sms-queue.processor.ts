import { Process, Processor } from '@nestjs/bull'
import { InjectModel } from '@nestjs/mongoose'
import { Job } from 'bull'
import { Model } from 'mongoose'
import * as firebaseAdmin from 'firebase-admin'
import { Device } from '../schemas/device.schema'
import { SMS } from '../schemas/sms.schema'
import { UsersService } from '../../users/users.service'
import { WebhookService } from 'src/webhook/webhook.service'
import { WebhookEvent } from 'src/webhook/webhook-event.enum'
import { Logger } from '@nestjs/common'
import {
  FCM_SEND_SKIPPED_ERROR_CODE,
  shouldSkipFcmSend,
  skippedBatchResponse,
} from '../fcm-send-skip'
import { errorHistoryPush } from '../error-history'
import { SmsBatchStatusService } from '../sms-batch-status.service'
import {
  FCM_SEND_TIMEOUT_ERROR_CODE,
  FcmSendTimeoutError,
  withSendTimeout,
} from './send-timeout'

function getFcmErrorCode(error: { code?: string; message?: string } | null): string {
  if (!error?.code) return 'FCM_DELIVERY_FAILED'
  const code = String(error.code).toLowerCase().replace(/^messaging\//, '')
  if (
    code === 'registration-token-not-registered' ||
    code === 'unregistered'
  ) {
    return 'FCM_TOKEN_NOT_REGISTERED'
  }
  if (
    code === 'invalid-registration-token' ||
    code === 'invalid-argument'
  ) {
    return 'FCM_INVALID_REGISTRATION_TOKEN'
  }
  if (code === 'mismatched-credential') {
    return 'FCM_PROJECT_MISMATCH'
  }
  return `FCM_DELIVERY_FAILED_${error.code}`
}

const FCM_ACTIONABLE_MESSAGE =
  'The device token is invalid. Please open the textbee mobile app, click on the update button to resync and try again.'

function getFcmErrorMessage(error: { code?: string; message?: string } | null | undefined): string {
  const rawPart = `FCM_DELIVERY_FAILED: ${error?.message || 'FCM delivery failed'}`
  return `${rawPart}. ${FCM_ACTIONABLE_MESSAGE}`
}

@Processor('sms')
export class SmsQueueProcessor {
  private readonly logger = new Logger(SmsQueueProcessor.name)

  constructor(
    @InjectModel(Device.name) private deviceModel: Model<Device>,
    @InjectModel(SMS.name) private smsModel: Model<SMS>,
    private webhookService: WebhookService,
    private usersService: UsersService,
    private batchStatus: SmsBatchStatusService,
  ) {}

  @Process({
    name: 'send-sms',
    concurrency: 10,
  })
  async handleSendSms(job: Job<any>) {
    // this.logger.debug(`Processing send-sms job ${job.id}`)
    const { deviceId, fcmMessages, smsBatchId } = job.data
    let pushHandedOff = false

    const device = await this.deviceModel
      .findById(deviceId)
      .populate('user')
      .exec()
    if (!device?.user) {
      this.logger.warn(
        `Device or user not found for deviceId ${deviceId}, webhooks will be skipped`,
      )
    }

    try {
      const skipped = shouldSkipFcmSend(device?.user, deviceId)
      const response = skipped
        ? skippedBatchResponse(fcmMessages.length)
        : await withSendTimeout(firebaseAdmin.messaging().sendEach(fcmMessages))
      // The push is done. Anything that throws from here on is a persistence
      // problem, and must not mark handed-off messages as failed a second time.
      pushHandedOff = true

      // this.logger.debug(
      //   `SMS Job ${job.id}( smsBatchId: ${smsBatchId}) completed, success: ${response.successCount}, failures: ${response.failureCount}`,
      // )

      // Mark individual SMS records as failed when their FCM push failed
      const failedSmsIds: string[] = []
      const failedUpdates: Array<{
        smsId: string
        errorCode: string
        errorMessage: string
      }> = []
      for (let i = 0; i < response.responses.length; i++) {
        if (!response.responses[i].success) {
          try {
            const smsData = JSON.parse(fcmMessages[i].data.smsData)
            const fcmError = response.responses[i].error
            failedSmsIds.push(String(smsData.smsId))
            failedUpdates.push({
              smsId: String(smsData.smsId),
              errorCode: getFcmErrorCode(fcmError ?? undefined),
              errorMessage: getFcmErrorMessage(fcmError ?? undefined),
            })
          } catch (parseError) {
            this.logger.error(
              `Failed to mark SMS as failed for FCM message index ${i}`,
              parseError,
            )
          }
        }
      }

      // Mark individual SMS records as dispatched when FCM push succeeded
      const now = new Date()
      const dispatchedSmsIds: string[] = []
      const dispatchedUpdates: Array<{
        smsId: string
        fcmMessageId?: string
      }> = []
      for (let i = 0; i < response.responses.length; i++) {
        if (response.responses[i].success) {
          try {
            const smsData = JSON.parse(fcmMessages[i].data.smsData)
            const messageId = response.responses[i].messageId
            dispatchedSmsIds.push(String(smsData.smsId))
            dispatchedUpdates.push({
              smsId: String(smsData.smsId),
              // The skip path fakes a response, so its sentinel is not an id
              ...(messageId &&
                messageId !== FCM_SEND_SKIPPED_ERROR_CODE && {
                  fcmMessageId: messageId,
                }),
            })
          } catch (parseError) {
            this.logger.error(
              `Failed to mark SMS as dispatched for FCM message index ${i}`,
              parseError,
            )
          }
        }
      }

      // One write per message: each row carries its own FCM message id and
      // its own failure entry
      const failedAt = new Date()
      const writes = [
        ...failedUpdates.map((failedUpdate) => ({
          updateOne: {
            filter: { _id: failedUpdate.smsId as any },
            update: {
              $set: {
                status: 'failed',
                failedAt,
                errorCode: failedUpdate.errorCode,
                errorMessage: failedUpdate.errorMessage,
              },
              $inc: { dispatchAttempts: 1 },
              ...(errorHistoryPush(
                {
                  code: failedUpdate.errorCode,
                  message: failedUpdate.errorMessage,
                  source: 'fcm',
                },
                failedAt,
              ) ?? {}),
            },
          },
        })),
        ...dispatchedUpdates.map((dispatchedUpdate) => ({
          updateOne: {
            // The phone may report before this write lands
            filter: {
              _id: dispatchedUpdate.smsId as any,
              status: { $nin: ['sent', 'delivered'] },
            },
            update: {
              $set: {
                status: 'dispatched',
                dispatchedAt: now,
                ...(skipped && { errorCode: FCM_SEND_SKIPPED_ERROR_CODE }),
                ...(dispatchedUpdate.fcmMessageId && {
                  'metadata.fcmMessageId': dispatchedUpdate.fcmMessageId,
                }),
              },
              $inc: { dispatchAttempts: 1 },
            },
          },
        })),
      ]

      if (writes.length > 0) {
        await this.smsModel.bulkWrite(writes as any, { ordered: false })
      }

      if (device?.user && failedSmsIds.length > 0) {
        const failedSmsDocuments = await this.smsModel.find({
          _id: { $in: failedSmsIds },
        })
        for (const failedSms of failedSmsDocuments) {
          await this.webhookService
            .deliverNotification({
              sms: failedSms,
              user: device.user as any,
              event: WebhookEvent.MESSAGE_FAILED,
            })
            .catch((e) =>
              this.logger.warn(
                `Webhook delivery failed for SMS ${failedSms._id}`,
                e?.message,
              ),
            )
        }
      }

      // Update device SMS count
      await this.deviceModel
        .findByIdAndUpdate(deviceId, {
          $inc: { sentSMSCount: response.successCount },
        })
        .exec()

      // device was loaded before the increment, so zero means this job carried
      // the account's first message.
      if (device?.user && device.sentSMSCount === 0 && response.successCount > 0) {
        this.usersService
          .markMilestone((device.user as any)?._id ?? device.user, 'firstSmsAt')
          .catch(() => undefined)
      }

      await this.batchStatus.refresh([smsBatchId])

      return response
    } catch (error) {
      this.logger.error(`Failed to process SMS job ${job.id}`, error)

      // Only the handoff itself gets the blanket failure. After it, the
      // per-message outcome is already written and a storage error here would
      // otherwise overwrite dispatched rows and double-count attempts.
      if (pushHandedOff) {
        await this.batchStatus.refresh([smsBatchId])
        throw error
      }

      // Mark all individual SMS in this batch of FCM messages as failed
      const failedSmsIds: string[] = []
      for (const fcmMessage of fcmMessages) {
        try {
          const smsData = JSON.parse(fcmMessage.data.smsData)
          failedSmsIds.push(String(smsData.smsId))
        } catch (parseError) {
          this.logger.error(
            'Failed to mark SMS as failed after FCM error',
            parseError,
          )
        }
      }

      const failedAt = new Date()
      if (failedSmsIds.length > 0) {
        const timedOut = error instanceof FcmSendTimeoutError
        const errorCode = timedOut
          ? FCM_SEND_TIMEOUT_ERROR_CODE
          : (error as any)?.code != null
            ? getFcmErrorCode(error as any)
            : 'FCM_SEND_ERROR'
        // A timeout says nothing about the token, so it skips the resync advice
        const errorMessage = timedOut
          ? `${FCM_SEND_TIMEOUT_ERROR_CODE}: ${error.message}`
          : getFcmErrorMessage(error as any)
        // The push may still have landed, so a phone report is not overwritten
        await this.smsModel.updateMany(
          {
            _id: { $in: failedSmsIds } as any,
            status: { $nin: ['sent', 'delivered'] },
          },
          {
            $set: {
              status: 'failed',
              failedAt,
              errorCode,
              errorMessage,
            },
            $inc: { dispatchAttempts: 1 },
            ...(errorHistoryPush(
              { code: errorCode, message: errorMessage, source: 'fcm' },
              failedAt,
            ) ?? {}),
          },
        )
      }

      if (device?.user && failedSmsIds.length > 0) {
        // Only the rows this failure actually changed
        const failedSmsDocuments = await this.smsModel.find({
          _id: { $in: failedSmsIds },
          status: 'failed',
          failedAt,
        })
        for (const failedSms of failedSmsDocuments) {
          await this.webhookService
            .deliverNotification({
              sms: failedSms,
              user: device.user as any,
              event: WebhookEvent.MESSAGE_FAILED,
            })
            .catch((e) =>
              this.logger.warn(
                `Webhook delivery failed for SMS ${failedSms._id}`,
                e?.message,
              ),
            )
        }
      }

      await this.batchStatus.refresh([smsBatchId])

      throw error
    }
  }
}
